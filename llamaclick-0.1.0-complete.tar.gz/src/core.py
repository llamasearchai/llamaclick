# Core library logic
