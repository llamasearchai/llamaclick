# Element interaction functionality
