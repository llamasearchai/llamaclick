# Complex user actions
