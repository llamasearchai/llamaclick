# Browser interaction layer
